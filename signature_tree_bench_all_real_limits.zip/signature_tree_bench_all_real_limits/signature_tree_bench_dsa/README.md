# Benchmark DSA

Cette version teste réellement DSA jusqu'à `N = 2^12`, puis passe en mode estimation pour les grandes valeurs jusqu'à `N = 2^30`.

DSA est plus lent et plus lourd qu'Ed25519, car chaque nœud possède une paire de clés DSA et une clé publique DER.

- `MODE_REAL` : construit l'arbre, génère les clés, signe, vérifie et libère la mémoire.
- `MODE_ESTIMATE` : calcule uniquement profondeur, capacité et statistiques théoriques, sans construire l'arbre.

Commandes :

```bash
make
make run
make valgrind
make clean
```
