#include "signature_tree_openssl.h"

/*
 * ============================================================
 * Fichier : signature_tree_openssl.c
 * ============================================================
 *
 * Rôle :
 *   Implémenter un arbre de signature hiérarchique avec OpenSSL + DSA.
 *
 * Principe :
 *   - on génère une fois des paramètres DSA communs (p, q, g),
 *   - chaque nœud reçoit sa propre paire de clés DSA,
 *   - la clé publique DER du fils est signée par le parent,
 *   - les messages des feuilles terminales sont signés par le nœud terminal.
 *
 * Détails cryptographiques :
 *   - DSA repose sur un sous-groupe d'un corps fini,
 *   - les opérations de signature/vérification utilisent SHA-256,
 *   - les clés publiques sont stockées au format DER pour simplifier
 *     l'authentification et la reconstruction des clés publiques.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <openssl/err.h>
#include <openssl/x509.h>
#include <openssl/core_names.h>
#include <openssl/provider.h>
#include <openssl/dsa.h>

/* ============================================================
 * OUTILS INTERNES
 * ============================================================
 */

/*
 * Affiche une erreur OpenSSL détaillée puis arrête le programme.
 *
 * Paramètre :
 *   msg : message à afficher avant la pile d'erreurs OpenSSL
 */
static void st_openssl_die(const char *msg) {
    fprintf(stderr, "%s\n", msg);
    ERR_print_errors_fp(stderr);
    exit(EXIT_FAILURE);
}

/*
 * Version sécurisée de malloc.
 * Arrête le programme si l'allocation échoue.
 */
static void *st_xmalloc(size_t n) {
    void *p = malloc(n);
    if (!p) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }
    return p;
}

/*
 * Version sécurisée de calloc.
 * Arrête le programme si l'allocation échoue.
 */
static void *st_xcalloc(size_t count, size_t size) {
    void *p = calloc(count, size);
    if (!p) {
        perror("calloc");
        exit(EXIT_FAILURE);
    }
    return p;
}

/*
 * Version sécurisée de realloc.
 * Arrête le programme si la réallocation échoue.
 */
static void *st_xrealloc(void *ptr, size_t n) {
    void *p = realloc(ptr, n);
    if (!p) {
        perror("realloc");
        exit(EXIT_FAILURE);
    }
    return p;
}

/*
 * Affiche une indentation de 2 espaces par niveau.
 */
static void st_print_indent(size_t level) {
    for (size_t i = 0; i < level; i++) {
        printf("  ");
    }
}

/*
 * Affiche les premiers octets d'un buffer en hexadécimal.
 *
 * Paramètres :
 *   buf        : buffer à afficher
 *   len        : longueur du buffer
 *   prefix_len : nombre maximal d'octets à afficher
 */
static void st_print_hex_prefix(const unsigned char *buf, size_t len, size_t prefix_len) {
    size_t n = (len < prefix_len) ? len : prefix_len;
    for (size_t i = 0; i < n; i++) {
        printf("%02x", buf[i]);
    }
    if (len > prefix_len) {
        printf("...");
    }
}

/*
 * Encode la clé publique d'un EVP_PKEY au format DER (SubjectPublicKeyInfo).
 *
 * Paramètre :
 *   pkey : clé publique ou paire de clés OpenSSL
 *
 * Retour :
 *   Un buffer contenant la représentation DER.
 *
 * Utilité :
 *   Cette représentation sert de donnée publique stable :
 *   - on peut la signer,
 *   - la stocker,
 *   - puis reconstruire la clé publique plus tard.
 */
static ST_Buffer st_public_key_to_der(EVP_PKEY *pkey) {
    ST_Buffer out;
    unsigned char *der = NULL;
    int len;

    st_buffer_init(&out);

    len = i2d_PUBKEY(pkey, &der);
    if (len <= 0) {
        st_openssl_die("i2d_PUBKEY a echoue");
    }

    out.data = der;
    out.len = (size_t)len;
    return out;
}

/*
 * Reconstruit une clé publique EVP_PKEY à partir d'un DER.
 *
 * Paramètres :
 *   der     : buffer DER
 *   der_len : longueur du DER
 *
 * Retour :
 *   Un EVP_PKEY* contenant la clé publique reconstruite.
 */
static EVP_PKEY *st_public_key_from_der(const unsigned char *der, size_t der_len) {
    const unsigned char *p = der;
    EVP_PKEY *pub = d2i_PUBKEY(NULL, &p, (long)der_len);

    if (!pub) {
        st_openssl_die("d2i_PUBKEY a echoue");
    }

    return pub;
}

/*
 * Signe un bloc de données avec DSA + SHA-256.
 *
 * Paramètres :
 *   pkey     : paire de clés DSA contenant la clé privée
 *   data     : données à signer
 *   data_len : longueur des données
 *
 * Retour :
 *   Un buffer contenant la signature.
 *
 * Remarque :
 *   Avec DSA via EVP, on utilise EVP_DigestSignInit + EVP_sha256().
 */
static ST_Buffer st_dsa_sign(EVP_PKEY *pkey, const unsigned char *data, size_t data_len) {
    EVP_MD_CTX *mdctx = EVP_MD_CTX_new();
    ST_Buffer out;
    size_t sig_len = 0;
    unsigned char *sig = NULL;

    st_buffer_init(&out);

    if (!mdctx) {
        st_openssl_die("EVP_MD_CTX_new a echoue");
    }

    if (EVP_DigestSignInit(mdctx, NULL, EVP_sha256(), NULL, pkey) <= 0) {
        EVP_MD_CTX_free(mdctx);
        st_openssl_die("EVP_DigestSignInit a echoue");
    }

    if (EVP_DigestSign(mdctx, NULL, &sig_len, data, data_len) <= 0) {
        EVP_MD_CTX_free(mdctx);
        st_openssl_die("EVP_DigestSign (taille) a echoue");
    }

    sig = (unsigned char *)st_xmalloc(sig_len);

    if (EVP_DigestSign(mdctx, sig, &sig_len, data, data_len) <= 0) {
        free(sig);
        EVP_MD_CTX_free(mdctx);
        st_openssl_die("EVP_DigestSign a echoue");
    }

    EVP_MD_CTX_free(mdctx);

    out.data = sig;
    out.len = sig_len;
    return out;
}

/*
 * Vérifie une signature DSA + SHA-256.
 *
 * Paramètres :
 *   pkey     : clé publique DSA
 *   data     : données signées
 *   data_len : longueur des données
 *   sig      : signature à vérifier
 *   sig_len  : longueur de la signature
 *
 * Retour :
 *   1 si la signature est valide, 0 sinon.
 */
static int st_dsa_verify(EVP_PKEY *pkey,
                         const unsigned char *data,
                         size_t data_len,
                         const unsigned char *sig,
                         size_t sig_len) {
    EVP_MD_CTX *mdctx = EVP_MD_CTX_new();
    int rc;

    if (!mdctx) {
        st_openssl_die("EVP_MD_CTX_new a echoue");
    }

    if (EVP_DigestVerifyInit(mdctx, NULL, EVP_sha256(), NULL, pkey) <= 0) {
        EVP_MD_CTX_free(mdctx);
        st_openssl_die("EVP_DigestVerifyInit a echoue");
    }

    rc = EVP_DigestVerify(mdctx, sig, sig_len, data, data_len);
    EVP_MD_CTX_free(mdctx);

    return rc == 1;
}

/*
 * Génère une paire de clés DSA à partir de paramètres DSA déjà créés.
 *
 * Paramètre :
 *   dsa_params : EVP_PKEY contenant uniquement les paramètres DSA
 *
 * Retour :
 *   Un EVP_PKEY* contenant une paire de clés DSA.
 */
static EVP_PKEY *st_generate_dsa_key_from_params(EVP_PKEY *dsa_params) {
    /*
     * Certaines configurations OpenSSL 3 refusent EVP_PKEY_keygen()
     * directement à partir d'un EVP_PKEY ne contenant que les paramètres DSA.
     * Pour rendre le code de test robuste, on récupère les paramètres DSA,
     * on les duplique, on génère la clé DSA, puis on ré-emballe le résultat
     * dans un EVP_PKEY.
     */
    DSA *params = EVP_PKEY_get1_DSA(dsa_params);
    DSA *key = NULL;
    EVP_PKEY *pkey = NULL;

    if (!params) {
        st_openssl_die("EVP_PKEY_get1_DSA a echoue");
    }

    key = DSAparams_dup(params);
    DSA_free(params);

    if (!key) {
        st_openssl_die("DSAparams_dup a echoue");
    }

    if (DSA_generate_key(key) != 1) {
        DSA_free(key);
        st_openssl_die("DSA_generate_key a echoue");
    }

    pkey = EVP_PKEY_new();
    if (!pkey) {
        DSA_free(key);
        st_openssl_die("EVP_PKEY_new a echoue");
    }

    if (EVP_PKEY_assign_DSA(pkey, key) != 1) {
        DSA_free(key);
        EVP_PKEY_free(pkey);
        st_openssl_die("EVP_PKEY_assign_DSA a echoue");
    }

    return pkey;
}

/* ============================================================
 * INITIALISATION OPENSSL
 * ============================================================
 */

void st_openssl_init(void) {
    ERR_load_crypto_strings();
    OpenSSL_add_all_algorithms();
    /* OpenSSL 3 peut placer DSA dans le provider legacy selon la configuration. */
    OSSL_PROVIDER_load(NULL, "default");
    OSSL_PROVIDER_load(NULL, "legacy");
}

void st_openssl_cleanup(void) {
    EVP_cleanup();
    ERR_free_strings();
}

/* ============================================================
 * GESTION DES BUFFERS
 * ============================================================
 */

void st_buffer_init(ST_Buffer *b) {
    if (!b) return;
    b->data = NULL;
    b->len = 0;
}

void st_buffer_free(ST_Buffer *b) {
    if (!b) return;
    free(b->data);
    b->data = NULL;
    b->len = 0;
}

/* ============================================================
 * PARAMETRES DSA
 * ============================================================
 */

EVP_PKEY *st_generate_dsa_parameters(int p_bits, int q_bits) {
    EVP_PKEY_CTX *pctx = EVP_PKEY_CTX_new_id(EVP_PKEY_DSA, NULL);
    EVP_PKEY *params = NULL;

    if (!pctx) {
        st_openssl_die("EVP_PKEY_CTX_new_id(EVP_PKEY_DSA) a echoue");
    }

    if (EVP_PKEY_paramgen_init(pctx) <= 0) {
        EVP_PKEY_CTX_free(pctx);
        st_openssl_die("EVP_PKEY_paramgen_init a echoue");
    }

    /*
     * Réglage de la taille des paramètres DSA.
     * Exemples classiques : p=2048 bits, q=256 bits.
     */
    if (EVP_PKEY_CTX_set_dsa_paramgen_bits(pctx, p_bits) <= 0) {
        EVP_PKEY_CTX_free(pctx);
        st_openssl_die("EVP_PKEY_CTX_set_dsa_paramgen_bits a echoue");
    }

    if (EVP_PKEY_CTX_set_dsa_paramgen_q_bits(pctx, q_bits) <= 0) {
        EVP_PKEY_CTX_free(pctx);
        st_openssl_die("EVP_PKEY_CTX_set_dsa_paramgen_q_bits a echoue");
    }

    /*
     * On demande ici SHA-256 pour aligner la génération avec q=256.
     */
    if (EVP_PKEY_CTX_set_dsa_paramgen_md(pctx, EVP_sha256()) <= 0) {
        EVP_PKEY_CTX_free(pctx);
        st_openssl_die("EVP_PKEY_CTX_set_dsa_paramgen_md a echoue");
    }

    if (EVP_PKEY_paramgen(pctx, &params) <= 0) {
        EVP_PKEY_CTX_free(pctx);
        st_openssl_die("EVP_PKEY_paramgen a echoue");
    }

    EVP_PKEY_CTX_free(pctx);
    return params;
}

/* ============================================================
 * CREATION / CONSTRUCTION DE L'ARBRE
 * ============================================================
 */

ST_SignatureNode *st_create_node(EVP_PKEY *dsa_params) {
    ST_SignatureNode *node = (ST_SignatureNode *)st_xcalloc(1, sizeof(ST_SignatureNode));

    /*
     * Génération de la paire de clés DSA du nœud à partir
     * des paramètres communs (p, q, g).
     */
    node->pkey = st_generate_dsa_key_from_params(dsa_params);

    /*
     * Extraction et stockage de la clé publique du nœud
     * sous forme DER.
     */
    node->pubkey_der = st_public_key_to_der(node->pkey);

    st_buffer_init(&node->auth_from_parent);
    node->has_parent_auth = 0;

    node->children = NULL;
    node->nb_children = 0;

    node->leaves = NULL;
    node->nb_leaves = 0;

    return node;
}

ST_SignatureNode *st_add_child(ST_SignatureNode *parent, EVP_PKEY *dsa_params) {
    ST_SignatureNode *child = st_create_node(dsa_params);

    /*
     * Le parent signe la clé publique DER du fils.
     * Cela permet d'authentifier cryptographiquement le lien
     * parent -> enfant.
     */
    child->auth_from_parent =
        st_dsa_sign(parent->pkey, child->pubkey_der.data, child->pubkey_der.len);
    child->has_parent_auth = 1;

    parent->children = (ST_SignatureNode **)st_xrealloc(
        parent->children,
        (parent->nb_children + 1) * sizeof(ST_SignatureNode *)
    );

    parent->children[parent->nb_children] = child;
    parent->nb_children++;

    return child;
}

void st_add_message_leaves(ST_SignatureNode *node, size_t t, const char *messages[]) {
    node->leaves = (ST_MessageLeaf *)st_xcalloc(t, sizeof(ST_MessageLeaf));
    node->nb_leaves = t;

    for (size_t i = 0; i < t; i++) {
        strncpy(node->leaves[i].message, messages[i], ST_MAX_MSG_LEN - 1);
        node->leaves[i].message[ST_MAX_MSG_LEN - 1] = '\0';
        st_buffer_init(&node->leaves[i].sig);
        node->leaves[i].used = 0;
    }
}

void st_build_tree(ST_SignatureNode *node,
                   EVP_PKEY *dsa_params,
                   size_t depth,
                   size_t t,
                   const char *messages[]) {
    if (depth == 0) {
        fprintf(stderr, "Erreur: depth doit etre >= 1\n");
        exit(EXIT_FAILURE);
    }

    /*
     * Si depth == 1, le nœud courant est terminal :
     * on lui ajoute directement t feuilles contenant t messages.
     */
    if (depth == 1) {
        st_add_message_leaves(node, t, messages);
        return;
    }

    /*
     * Sinon, le nœud courant est interne :
     * on lui ajoute t fils puis on construit récursivement
     * leur sous-arbre.
     */
    for (size_t i = 0; i < t; i++) {
        ST_SignatureNode *child = st_add_child(node, dsa_params);
        st_build_tree(child, dsa_params, depth - 1, t, messages);
    }
}


/* ============================================================
 * CONSTRUCTION AUTOMATIQUE POUR BENCHMARK
 * ============================================================
 * Construit un arbre capable de signer exactement n_messages messages
 * nommés automatiquement : message_0, message_1, ...
 */
static void st_add_auto_message_leaves(ST_SignatureNode *node,
                                       size_t t,
                                       size_t n_messages,
                                       size_t *next_id) {
    if (!node || !next_id || *next_id >= n_messages) {
        return;
    }

    size_t remaining = n_messages - *next_id;
    size_t nb = (remaining < t) ? remaining : t;

    node->leaves = (ST_MessageLeaf *)st_xcalloc(nb, sizeof(ST_MessageLeaf));
    node->nb_leaves = nb;

    for (size_t i = 0; i < nb; i++) {
        snprintf(node->leaves[i].message,
                 ST_MAX_MSG_LEN,
                 "message_%zu",
                 *next_id);
        st_buffer_init(&node->leaves[i].sig);
        node->leaves[i].used = 0;
        (*next_id)++;
    }
}

static void st_build_tree_auto_rec(ST_SignatureNode *node,
                                   EVP_PKEY *dsa_params,
                                   size_t depth,
                                   size_t t,
                                   size_t n_messages,
                                   size_t *next_id) {
    if (!node || !next_id || *next_id >= n_messages) {
        return;
    }

    if (depth == 1) {
        st_add_auto_message_leaves(node, t, n_messages, next_id);
        return;
    }

    for (size_t i = 0; i < t && *next_id < n_messages; i++) {
        ST_SignatureNode *child = st_add_child(node, dsa_params);
        st_build_tree_auto_rec(child, dsa_params, depth - 1, t, n_messages, next_id);
    }
}

void st_build_tree_auto(ST_SignatureNode *root,
                        EVP_PKEY *dsa_params,
                        size_t depth,
                        size_t t,
                        size_t n_messages) {
    if (!root || !dsa_params) {
        fprintf(stderr, "Erreur: root ou dsa_params NULL\n");
        exit(EXIT_FAILURE);
    }
    if (depth == 0) {
        fprintf(stderr, "Erreur: depth doit etre >= 1\n");
        exit(EXIT_FAILURE);
    }
    if (t < 2) {
        fprintf(stderr, "Erreur: t doit etre >= 2\n");
        exit(EXIT_FAILURE);
    }
    if (n_messages == 0) {
        fprintf(stderr, "Erreur: n_messages doit etre >= 1\n");
        exit(EXIT_FAILURE);
    }

    size_t next_id = 0;
    st_build_tree_auto_rec(root, dsa_params, depth, t, n_messages, &next_id);

    if (next_id != n_messages) {
        fprintf(stderr,
                "Erreur interne: seulement %zu/%zu messages ont ete generes\n",
                next_id,
                n_messages);
        exit(EXIT_FAILURE);
    }
}

/* ============================================================
 * AFFICHAGE / STATISTIQUES
 * ============================================================
 */

void st_print_tree(const ST_SignatureNode *node, size_t level) {
    st_print_indent(level);
    printf("Node(level=%zu, children=%zu, leaves=%zu, pubkey_der=",
           level, node->nb_children, node->nb_leaves);
    st_print_hex_prefix(node->pubkey_der.data, node->pubkey_der.len, 8);
    printf(")\n");

    if (node->has_parent_auth) {
        st_print_indent(level + 1);
        printf("auth_from_parent=");
        st_print_hex_prefix(node->auth_from_parent.data, node->auth_from_parent.len, 8);
        printf("\n");
    }

    for (size_t i = 0; i < node->nb_leaves; i++) {
        st_print_indent(level + 1);
        printf("Leaf[%zu]: msg=\"%s\", used=%d",
               i, node->leaves[i].message, node->leaves[i].used);

        if (node->leaves[i].used) {
            printf(", sig=");
            st_print_hex_prefix(node->leaves[i].sig.data, node->leaves[i].sig.len, 8);
        }

        printf("\n");
    }

    for (size_t i = 0; i < node->nb_children; i++) {
        st_print_tree(node->children[i], level + 1);
    }
}

size_t st_count_total_nodes(const ST_SignatureNode *node) {
    size_t total = 1;

    for (size_t i = 0; i < node->nb_children; i++) {
        total += st_count_total_nodes(node->children[i]);
    }

    return total;
}

size_t st_count_total_leaves(const ST_SignatureNode *node) {
    size_t total = node->nb_leaves;

    for (size_t i = 0; i < node->nb_children; i++) {
        total += st_count_total_leaves(node->children[i]);
    }

    return total;
}

size_t st_count_signed_leaves(const ST_SignatureNode *node) {
    size_t total = 0;

    for (size_t i = 0; i < node->nb_leaves; i++) {
        if (node->leaves[i].used) {
            total++;
        }
    }

    for (size_t i = 0; i < node->nb_children; i++) {
        total += st_count_signed_leaves(node->children[i]);
    }

    return total;
}

/* ============================================================
 * SIGNATURE DU PROCHAIN MESSAGE
 * ============================================================
 */

/*
 * Fonction récursive interne :
 * parcourt l'arbre de gauche à droite et signe la première feuille libre.
 *
 * Paramètres :
 *   node         : nœud courant
 *   path_nodes   : tableau temporaire contenant les nœuds du chemin
 *   path_indexes : tableau temporaire contenant les indices de fils
 *   depth        : profondeur courante
 *   result       : structure résultat à remplir
 *
 * Retour :
 *   1 si une signature a été produite, 0 sinon.
 */
static int st_sign_next_message_rec(ST_SignatureNode *node,
                                    ST_SignatureNode **path_nodes,
                                    size_t *path_indexes,
                                    size_t depth,
                                    ST_SignResult *result) {
    path_nodes[depth] = node;

    /*
     * Cas terminal :
     * on cherche la première feuille dont used == 0.
     */
    if (node->nb_leaves > 0) {
        for (size_t i = 0; i < node->nb_leaves; i++) {
            if (!node->leaves[i].used) {
                node->leaves[i].sig = st_dsa_sign(
                    node->pkey,
                    (const unsigned char *)node->leaves[i].message,
                    strlen(node->leaves[i].message)
                );
                node->leaves[i].used = 1;

                result->success = 1;

                strncpy(result->message, node->leaves[i].message, ST_MAX_MSG_LEN - 1);
                result->message[ST_MAX_MSG_LEN - 1] = '\0';

                result->message_signature.data =
                    (unsigned char *)st_xmalloc(node->leaves[i].sig.len);
                memcpy(result->message_signature.data,
                       node->leaves[i].sig.data,
                       node->leaves[i].sig.len);
                result->message_signature.len = node->leaves[i].sig.len;

                result->leaf_index = i;
                result->path_len = depth + 1;

                for (size_t k = 0; k < result->path_len; k++) {
                    result->path_nodes[k] = path_nodes[k];
                }

                for (size_t k = 0; k + 1 < result->path_len; k++) {
                    result->path_child_indexes[k] = path_indexes[k];
                }

                return 1;
            }
        }

        return 0;
    }

    /*
     * Cas interne :
     * on explore les fils dans l'ordre.
     */
    for (size_t i = 0; i < node->nb_children; i++) {
        path_indexes[depth] = i;

        if (st_sign_next_message_rec(node->children[i],
                                     path_nodes,
                                     path_indexes,
                                     depth + 1,
                                     result)) {
            return 1;
        }
    }

    return 0;
}

ST_SignResult st_sign_next_message(ST_SignatureNode *root, size_t max_depth) {
    ST_SignResult result;

    result.success = 0;
    result.message[0] = '\0';
    st_buffer_init(&result.message_signature);
    result.path_len = 0;
    result.leaf_index = 0;

    result.path_nodes = (ST_SignatureNode **)st_xmalloc(max_depth * sizeof(ST_SignatureNode *));
    result.path_child_indexes = (size_t *)st_xmalloc(max_depth * sizeof(size_t));

    ST_SignatureNode **tmp_nodes =
        (ST_SignatureNode **)st_xmalloc(max_depth * sizeof(ST_SignatureNode *));
    size_t *tmp_indexes =
        (size_t *)st_xmalloc(max_depth * sizeof(size_t));

    int ok = st_sign_next_message_rec(root, tmp_nodes, tmp_indexes, 0, &result);

    free(tmp_nodes);
    free(tmp_indexes);

    if (!ok) {
        result.success = 0;
    }

    return result;
}

void st_free_sign_result(ST_SignResult *res) {
    if (!res) return;

    st_buffer_free(&res->message_signature);

    free(res->path_nodes);
    free(res->path_child_indexes);

    res->path_nodes = NULL;
    res->path_child_indexes = NULL;
}

/* ============================================================
 * VERIFICATION
 * ============================================================
 */

int st_verify_sign_result(const ST_SignResult *res) {
    if (!res || !res->success || res->path_len == 0) {
        return 0;
    }

    /*
     * Vérification de chaque authentification parent -> enfant.
     * On reconstruit la clé publique du parent à partir de son DER,
     * puis on vérifie la signature de la clé publique DER du fils.
     */
    for (size_t i = 0; i + 1 < res->path_len; i++) {
        const ST_SignatureNode *parent = res->path_nodes[i];
        const ST_SignatureNode *child = res->path_nodes[i + 1];
        EVP_PKEY *parent_pub = NULL;
        int ok;

        if (!child->has_parent_auth) {
            return 0;
        }

        parent_pub = st_public_key_from_der(parent->pubkey_der.data, parent->pubkey_der.len);

        ok = st_dsa_verify(parent_pub,
                           child->pubkey_der.data,
                           child->pubkey_der.len,
                           child->auth_from_parent.data,
                           child->auth_from_parent.len);

        EVP_PKEY_free(parent_pub);

        if (!ok) {
            return 0;
        }
    }

    /*
     * Vérification finale de la signature du message
     * avec la clé publique du nœud terminal.
     */
    {
        const ST_SignatureNode *terminal = res->path_nodes[res->path_len - 1];
        EVP_PKEY *terminal_pub =
            st_public_key_from_der(terminal->pubkey_der.data, terminal->pubkey_der.len);

        int ok = st_dsa_verify(terminal_pub,
                               (const unsigned char *)res->message,
                               strlen(res->message),
                               res->message_signature.data,
                               res->message_signature.len);

        EVP_PKEY_free(terminal_pub);
        return ok;
    }
}

/* ============================================================
 * LIBERATION MEMOIRE
 * ============================================================
 */

void st_free_tree(ST_SignatureNode *node) {
    if (!node) return;

    /*
     * Libération récursive des fils.
     */
    for (size_t i = 0; i < node->nb_children; i++) {
        st_free_tree(node->children[i]);
    }

    /*
     * Libération des signatures des feuilles terminales.
     */
    for (size_t i = 0; i < node->nb_leaves; i++) {
        st_buffer_free(&node->leaves[i].sig);
    }

    free(node->children);
    free(node->leaves);

    /*
     * Libération des buffers propres au nœud.
     */
    st_buffer_free(&node->pubkey_der);
    st_buffer_free(&node->auth_from_parent);

    /*
     * Libération de la paire de clés OpenSSL du nœud.
     */
    if (node->pkey) {
        EVP_PKEY_free(node->pkey);
    }

    free(node);
}