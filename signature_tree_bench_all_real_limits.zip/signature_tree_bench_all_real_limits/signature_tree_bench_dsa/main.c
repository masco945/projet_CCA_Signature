
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <limits.h>
#include "signature_tree_openssl.h"

#define TIME_DIFF_MS(start, end) \
    (((end).tv_sec - (start).tv_sec) * 1000.0 + \
     ((end).tv_nsec - (start).tv_nsec) / 1000000.0)

#define MODE_REAL      1
#define MODE_ESTIMATE  0

typedef struct {
    size_t n_messages;      /* N : nombre exact de messages à signer */
    size_t t;               /* facteur de branchement */
    int p_bits;             /* taille de p */
    int q_bits;             /* taille de q */
    int print_tree;         /* 1 pour afficher l'arbre complet */
    int real_run;           /* 1 = construit/signe vraiment, 0 = estimation */
} BenchmarkCase;

static size_t checked_mul(size_t a, size_t b) {
    if (a != 0 && b > SIZE_MAX / a) {
        fprintf(stderr, "Overflow dans le calcul de capacite\n");
        exit(EXIT_FAILURE);
    }
    return a * b;
}

static size_t checked_add(size_t a, size_t b) {
    if (b > SIZE_MAX - a) {
        fprintf(stderr, "Overflow dans le calcul du nombre de noeuds\n");
        exit(EXIT_FAILURE);
    }
    return a + b;
}

static size_t pow_size(size_t base, size_t exp) {
    size_t r = 1;
    for (size_t i = 0; i < exp; i++) {
        r = checked_mul(r, base);
    }
    return r;
}

/*
 * Profondeur minimale selon la convention du module :
 * - depth == 1 permet déjà jusqu'à t messages,
 * - donc on prend le plus petit depth >= 1 tel que t^depth >= N.
 */
static size_t compute_depth_from_N(size_t N, size_t t) {
    if (N == 0 || t < 2) {
        fprintf(stderr, "Parametres invalides: N >= 1 et t >= 2 requis\n");
        exit(EXIT_FAILURE);
    }

    size_t depth = 1;
    size_t capacity = t;

    while (capacity < N) {
        capacity = checked_mul(capacity, t);
        depth++;
    }

    return depth;
}

/* Nombre de noeuds ST_SignatureNode : 1 + t + ... + t^(depth-1). */
static size_t theoretical_node_count(size_t t, size_t depth) {
    size_t total = 0;
    size_t level_nodes = 1;

    for (size_t level = 0; level < depth; level++) {
        total = checked_add(total, level_nodes);
        if (level + 1 < depth) {
            level_nodes = checked_mul(level_nodes, t);
        }
    }

    return total;
}

static void print_estimation_case(const BenchmarkCase *tc) {
    const size_t N = tc->n_messages;
    const size_t t = tc->t;
    const size_t depth = compute_depth_from_N(N, t);
    const size_t capacity = pow_size(t, depth);
    const size_t nodes = theoretical_node_count(t, depth);

    printf("| DSA     | %11zu | %5zu | %5zu | %11zu | %11zu | %11zu | %11s | %4d | %4d | %10s | %10s | %10s | %10s | %10s | %11s | %s |\n",
           N,
           t,
           depth,
           capacity,
           nodes,
           N,
           "-",
           tc->p_bits,
           tc->q_bits,
           "-",
           "-",
           "-",
           "-",
           "-",
           "-",
           "ESTIMATION");
}

static void run_real_case(const BenchmarkCase *tc) {
    const size_t N = tc->n_messages;
    const size_t t = tc->t;
    const size_t depth = compute_depth_from_N(N, t);
    const size_t capacity = pow_size(t, depth);

    struct timespec a, b, c, d, e, f, g, h;
    double params_ms, build_ms, sign_ms, free_ms, total_ms;
    size_t signed_count = 0;
    size_t verified_count = 0;

    clock_gettime(CLOCK_MONOTONIC, &a);

    EVP_PKEY *dsa_params = st_generate_dsa_parameters(tc->p_bits, tc->q_bits);
    clock_gettime(CLOCK_MONOTONIC, &b);
    params_ms = TIME_DIFF_MS(a, b);

    ST_SignatureNode *root = st_create_node(dsa_params);

    clock_gettime(CLOCK_MONOTONIC, &c);
    st_build_tree_auto(root, dsa_params, depth, t, N);
    clock_gettime(CLOCK_MONOTONIC, &d);
    build_ms = TIME_DIFF_MS(c, d);

    EVP_PKEY_free(dsa_params);
    dsa_params = NULL;

    size_t total_nodes = st_count_total_nodes(root);
    size_t total_leaves = st_count_total_leaves(root);

    if (tc->print_tree) {
        printf("\n===== ARBRE DSA N=%zu t=%zu depth=%zu =====\n", N, t, depth);
        st_print_tree(root, 0);
    }

    clock_gettime(CLOCK_MONOTONIC, &e);

    while (signed_count < N) {
        ST_SignResult res = st_sign_next_message(root, depth);
        if (!res.success) {
            st_free_sign_result(&res);
            break;
        }

        signed_count++;
        if (st_verify_sign_result(&res)) {
            verified_count++;
        }
        st_free_sign_result(&res);
    }

    clock_gettime(CLOCK_MONOTONIC, &f);
    sign_ms = TIME_DIFF_MS(e, f);

    clock_gettime(CLOCK_MONOTONIC, &g);
    st_free_tree(root);
    clock_gettime(CLOCK_MONOTONIC, &h);

    free_ms = TIME_DIFF_MS(g, h);
    total_ms = TIME_DIFF_MS(a, h);

    printf("| DSA     | %11zu | %5zu | %5zu | %11zu | %11zu | %11zu | %11zu | %4d | %4d | %10.3f | %10.3f | %10.3f | %10.3f | %10.3f | %11.3f | %s |\n",
           N,
           t,
           depth,
           capacity,
           total_nodes,
           total_leaves,
           verified_count,
           tc->p_bits,
           tc->q_bits,
           params_ms,
           build_ms,
           sign_ms,
           (N > 0) ? sign_ms / (double)N : 0.0,
           free_ms,
           total_ms,
           "REEL");
}

static void run_case(const BenchmarkCase *tc) {
    if (tc->real_run == MODE_REAL) {
        run_real_case(tc);
    } else {
        print_estimation_case(tc);
    }
}

int main(void) {
    const size_t N_MAX = ((size_t)1 << 30); /* 2^30 */

    const BenchmarkCase tests[] = {
        /*
         * Tests réels DSA : DSA est beaucoup plus lourd que Ed25519.
         * On reste donc sur des tailles raisonnables, jusqu'à N = 2^12.
         */
        { ((size_t)1 << 4),  3, 2048, 256, 1, MODE_REAL },  /* 16 messages */
        { ((size_t)1 << 6),  3, 2048, 256, 0, MODE_REAL },  /* 64 messages */
        { ((size_t)1 << 8),  3, 2048, 256, 0, MODE_REAL },  /* 256 messages */
        { ((size_t)1 << 10), 3, 2048, 256, 0, MODE_REAL },  /* 1 024 messages */
        { ((size_t)1 << 12), 3, 2048, 256, 0, MODE_REAL },  /* 4 096 messages */

        /*
         * Grandes valeurs : estimation uniquement.
         * À partir de N = 2^16, on évite de construire réellement l'arbre.
         */
        { ((size_t)1 << 16), 3, 2048, 256, 0, MODE_ESTIMATE },
        { ((size_t)1 << 20), 3, 2048, 256, 0, MODE_ESTIMATE },
        { ((size_t)1 << 25), 3, 2048, 256, 0, MODE_ESTIMATE },
        { N_MAX,             3, 2048, 256, 0, MODE_ESTIMATE }
    };

    const size_t nb_tests = sizeof(tests) / sizeof(tests[0]);

    st_openssl_init();

    printf("\n===== BENCHMARK ARBRE DE SIGNATURE DSA =====\n");
    printf("N est le nombre exact de messages. Les petits N sont testes reellement.\n");
    printf("Les grands N, jusqu'a 2^30, sont affiches en estimation theorique pour eviter l'explosion memoire.\n");
    printf("depth est calcule automatiquement avec le plus petit depth tel que t^depth >= N.\n");
    printf("Remarque: la generation des parametres DSA est beaucoup plus lente que Ed25519.\n\n");

    printf("| algo    |           N |     t | depth |    capacity |       nodes |      leaves |    verified | p    | q    | params ms |   build ms |    sign ms |    ms/sign |    free ms |    total ms | mode       |\n");
    printf("|---------|-------------|-------|-------|-------------|-------------|-------------|-------------|------|------|-----------|------------|------------|------------|------------|-------------|------------|\n");

    for (size_t i = 0; i < nb_tests; i++) {
        run_case(&tests[i]);
    }

    st_openssl_cleanup();
    return 0;
}
