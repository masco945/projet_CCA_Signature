# Benchmark Ed25519

Cette version teste réellement Ed25519 jusqu'à `N = 2^16`, puis passe en mode estimation pour les grandes valeurs jusqu'à `N = 2^30`.

- `MODE_REAL` : construit l'arbre, génère les clés, signe, vérifie et libère la mémoire.
- `MODE_ESTIMATE` : calcule uniquement profondeur, capacité, nombre de nœuds/feuilles et taille théorique, sans construire l'arbre.

Commandes :

```bash
make
make run
make valgrind
make clean
```
