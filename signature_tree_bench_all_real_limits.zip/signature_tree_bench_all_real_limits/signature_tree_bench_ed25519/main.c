
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <limits.h>
#include "signature_tree_openssl.h"

#define TIME_DIFF_MS(start, end) \
    (((end).tv_sec - (start).tv_sec) * 1000.0 + \
     ((end).tv_nsec - (start).tv_nsec) / 1000000.0)

#define PUBKEY_BITS  (ST_ED25519_PUBKEY_LEN * 8)
#define SIG_BITS     (ST_ED25519_SIG_LEN * 8)
#define SCALAR_BITS  256

/*
 * Pour les très grands N, par exemple 2^30, on ne construit pas réellement
 * l'arbre : cela demanderait énormément de mémoire.
 * On affiche donc une ligne d'estimation théorique.
 */
#define MODE_REAL      1
#define MODE_ESTIMATE  0

typedef struct {
    size_t n_messages;      /* N : nombre exact de messages à signer */
    size_t t;               /* facteur de branchement */
    int print_tree;         /* 1 pour afficher l'arbre complet */
    int real_run;           /* 1 = construit/signe vraiment, 0 = estimation */
} BenchmarkCase;

static size_t checked_mul(size_t a, size_t b) {
    if (a != 0 && b > SIZE_MAX / a) {
        fprintf(stderr, "Overflow dans le calcul de capacite\n");
        exit(EXIT_FAILURE);
    }
    return a * b;
}

static size_t checked_add(size_t a, size_t b) {
    if (b > SIZE_MAX - a) {
        fprintf(stderr, "Overflow dans le calcul du nombre de noeuds\n");
        exit(EXIT_FAILURE);
    }
    return a + b;
}

static size_t pow_size(size_t base, size_t exp) {
    size_t r = 1;
    for (size_t i = 0; i < exp; i++) {
        r = checked_mul(r, base);
    }
    return r;
}

/*
 * Profondeur minimale selon la convention du module :
 * - depth == 1 signifie déjà jusqu'à t messages,
 * - donc on prend le plus petit depth >= 1 tel que t^depth >= N.
 */
static size_t compute_depth_from_N(size_t N, size_t t) {
    if (N == 0 || t < 2) {
        fprintf(stderr, "Parametres invalides: N >= 1 et t >= 2 requis\n");
        exit(EXIT_FAILURE);
    }

    size_t depth = 1;
    size_t capacity = t;

    while (capacity < N) {
        capacity = checked_mul(capacity, t);
        depth++;
    }

    return depth;
}

/*
 * Nombre de noeuds d'un arbre complet de profondeur depth :
 * 1 + t + t^2 + ... + t^(depth-1).
 * Attention : les feuilles-message ne sont pas des noeuds ST_SignatureNode.
 */
static size_t theoretical_node_count(size_t t, size_t depth) {
    size_t total = 0;
    size_t level_nodes = 1;

    for (size_t level = 0; level < depth; level++) {
        total = checked_add(total, level_nodes);
        if (level + 1 < depth) {
            level_nodes = checked_mul(level_nodes, t);
        }
    }

    return total;
}

static unsigned long long theoretical_signature_bits(size_t depth, size_t t) {
    return (unsigned long long)(depth - 1) * PUBKEY_BITS
         + (unsigned long long)depth * SIG_BITS
         + (unsigned long long)(t + 1) * SCALAR_BITS;
}

static void print_estimation_case(const BenchmarkCase *tc) {
    const size_t N = tc->n_messages;
    const size_t t = tc->t;
    const size_t depth = compute_depth_from_N(N, t);
    const size_t capacity = pow_size(t, depth);
    const size_t nodes = theoretical_node_count(t, depth);

    printf("| Ed25519 | %11zu | %5zu | %5zu | %11zu | %11zu | %11zu | %11s | %10s | %10s | %10s | %10s | %11s | %12llu | %s |\n",
           N,
           t,
           depth,
           capacity,
           nodes,
           N,
           "-",
           "-",
           "-",
           "-",
           "-",
           "-",
           theoretical_signature_bits(depth, t),
           "ESTIMATION");
}

static void run_real_case(const BenchmarkCase *tc) {
    const size_t N = tc->n_messages;
    const size_t t = tc->t;
    const size_t depth = compute_depth_from_N(N, t);
    const size_t capacity = pow_size(t, depth);

    struct timespec a, b, c, d, e;
    double build_ms, sign_ms, free_ms, total_ms;
    size_t signed_count = 0;
    size_t verified_count = 0;

    clock_gettime(CLOCK_MONOTONIC, &a);

    ST_SignatureNode *root = st_create_node();

    clock_gettime(CLOCK_MONOTONIC, &b);
    st_build_tree_auto(root, depth, t, N);
    clock_gettime(CLOCK_MONOTONIC, &c);

    build_ms = TIME_DIFF_MS(b, c);

    size_t total_nodes = st_count_total_nodes(root);
    size_t total_leaves = st_count_total_leaves(root);

    if (tc->print_tree) {
        printf("\n===== ARBRE ED25519 N=%zu t=%zu depth=%zu =====\n", N, t, depth);
        st_print_tree(root, 0);
    }

    clock_gettime(CLOCK_MONOTONIC, &d);

    while (signed_count < N) {
        ST_SignResult res = st_sign_next_message(root, depth);
        if (!res.success) {
            st_free_sign_result(&res);
            break;
        }

        signed_count++;
        if (st_verify_sign_result(&res)) {
            verified_count++;
        }
        st_free_sign_result(&res);
    }

    clock_gettime(CLOCK_MONOTONIC, &e);
    sign_ms = TIME_DIFF_MS(d, e);

    struct timespec f, g;
    clock_gettime(CLOCK_MONOTONIC, &f);
    st_free_tree(root);
    clock_gettime(CLOCK_MONOTONIC, &g);
    free_ms = TIME_DIFF_MS(f, g);
    total_ms = TIME_DIFF_MS(a, g);

    printf("| Ed25519 | %11zu | %5zu | %5zu | %11zu | %11zu | %11zu | %11zu | %10.3f | %10.3f | %10.3f | %10.3f | %11.3f | %12llu | %s |\n",
           N,
           t,
           depth,
           capacity,
           total_nodes,
           total_leaves,
           verified_count,
           build_ms,
           sign_ms,
           (N > 0) ? sign_ms / (double)N : 0.0,
           free_ms,
           total_ms,
           theoretical_signature_bits(depth, t),
           "REEL");
}

static void run_case(const BenchmarkCase *tc) {
    if (tc->real_run == MODE_REAL) {
        run_real_case(tc);
    } else {
        print_estimation_case(tc);
    }
}

int main(void) {
    const size_t N_MAX = ((size_t)1 << 30); /* 2^30 */

    const BenchmarkCase tests[] = {
        /*
         * Tests réels Ed25519 : raisonnables sur une machine classique.
         * On monte jusqu'à N = 2^16. Au-delà, l'arbre complet devient
         * vite très coûteux en mémoire et en temps.
         */
        { ((size_t)1 << 8),  4, 0, MODE_REAL },   /* 256 messages */
        { ((size_t)1 << 10), 4, 0, MODE_REAL },   /* 1 024 messages */
        { ((size_t)1 << 12), 4, 0, MODE_REAL },   /* 4 096 messages */
        { ((size_t)1 << 14), 4, 0, MODE_REAL },   /* 16 384 messages */
        { ((size_t)1 << 16), 4, 0, MODE_REAL },   /* 65 536 messages */

        /*
         * Grandes valeurs : estimation uniquement.
         * Ces tests permettent d'aller jusqu'à N = 2^30 sans construire
         * des centaines de millions de nœuds en mémoire.
         */
        { ((size_t)1 << 20), 4, 0, MODE_ESTIMATE },
        { ((size_t)1 << 25), 4, 0, MODE_ESTIMATE },
        { N_MAX,             4, 0, MODE_ESTIMATE }
    };

    const size_t nb_tests = sizeof(tests) / sizeof(tests[0]);

    st_openssl_init();

    printf("\n===== BENCHMARK ARBRE DE SIGNATURE ED25519 =====\n");
    printf("N est le nombre exact de messages. Les petits N sont testes reellement.\n");
    printf("Les grands N, jusqu'a 2^30, sont affiches en estimation theorique pour eviter l'explosion memoire.\n");
    printf("depth est calcule automatiquement avec le plus petit depth tel que t^depth >= N.\n\n");

    printf("| algo    |           N |     t | depth |    capacity |       nodes |      leaves |    verified |   build ms |    sign ms |    ms/sign |    free ms |    total ms |     sig bits | mode       |\n");
    printf("|---------|-------------|-------|-------|-------------|-------------|-------------|-------------|------------|------------|------------|------------|-------------|--------------|------------|\n");

    for (size_t i = 0; i < nb_tests; i++) {
        run_case(&tests[i]);
    }

    st_openssl_cleanup();
    return 0;
}
