import matplotlib.pyplot as plt


# ============================================================
# Données expérimentales Ed25519
# ============================================================

ed25519 = {
    "N": [256, 1024, 4096, 16384, 65536],
    "t": [4, 4, 4, 4, 4],
    "depth": [4, 5, 6, 7, 8],
    "capacity": [256, 1024, 4096, 16384, 65536],
    "nodes": [85, 341, 1365, 5461, 21845],
    "leaves": [256, 1024, 4096, 16384, 65536],
    "verified": [256, 1024, 4096, 16384, 65536],
    "build_ms": [11.865, 34.053, 140.413, 554.694, 2208.410],
    "sign_ms": [153.434, 757.969, 3599.443, 17345.460, 97924.974],
    "ms_per_sign": [0.599, 0.740, 0.879, 1.059, 1.494],
    "total_ms": [175.725, 792.269, 3740.966, 17904.118, 100151.205],
}


# ============================================================
# Données expérimentales DSA
# ============================================================

dsa = {
    "N": [16, 64, 256, 1024, 4096],
    "t": [3, 3, 3, 3, 3],
    "depth": [3, 4, 6, 7, 8],
    "capacity": [27, 81, 729, 2187, 6561],
    "nodes": [9, 34, 132, 515, 2051],
    "leaves": [16, 64, 256, 1024, 4096],
    "verified": [16, 64, 256, 1024, 4096],
    "p": [2048, 2048, 2048, 2048, 2048],
    "q": [256, 256, 256, 256, 256],
    "params_ms": [658.898, 361.464, 581.580, 178.506, 224.060],
    "build_ms": [9.292, 36.003, 146.307, 569.144, 2275.445],
    "sign_ms": [29.084, 139.049, 773.115, 3547.827, 15711.604],
    "ms_per_sign": [1.818, 2.173, 3.020, 3.465, 3.836],
    "total_ms": [698.219, 537.304, 1501.932, 4297.991, 18217.371],
}


# ============================================================
# Fonction utilitaire
# ============================================================

def save_plot(filename):
    plt.tight_layout()
    plt.savefig(filename, dpi=300)
    plt.show()


# ============================================================
# 1. Temps de construction en fonction de N
# ============================================================

plt.figure(figsize=(8, 5))
plt.plot(ed25519["N"], ed25519["build_ms"], marker="o", label="Ed25519")
plt.plot(dsa["N"], dsa["build_ms"], marker="o", label="DSA")

plt.xscale("log", base=2)
plt.yscale("log")

plt.xlabel("Nombre de messages N")
plt.ylabel("Temps de construction (ms)")
plt.title("Comparaison du temps de construction")
plt.grid(True, which="both")
plt.legend()

save_plot("comparaison_build_ms.png")


# ============================================================
# 2. Temps total de signature + vérification
# ============================================================

plt.figure(figsize=(8, 5))
plt.plot(ed25519["N"], ed25519["sign_ms"], marker="o", label="Ed25519")
plt.plot(dsa["N"], dsa["sign_ms"], marker="o", label="DSA")

plt.xscale("log", base=2)
plt.yscale("log")

plt.xlabel("Nombre de messages N")
plt.ylabel("Temps signature + vérification (ms)")
plt.title("Comparaison du temps de signature et vérification")
plt.grid(True, which="both")
plt.legend()

save_plot("comparaison_sign_ms.png")


# ============================================================
# 3. Temps moyen par signature
# ============================================================

plt.figure(figsize=(8, 5))
plt.plot(ed25519["N"], ed25519["ms_per_sign"], marker="o", label="Ed25519")
plt.plot(dsa["N"], dsa["ms_per_sign"], marker="o", label="DSA")

plt.xscale("log", base=2)

plt.xlabel("Nombre de messages N")
plt.ylabel("Temps moyen par signature (ms)")
plt.title("Comparaison du temps moyen par signature")
plt.grid(True, which="both")
plt.legend()

save_plot("comparaison_ms_par_signature.png")


# ============================================================
# 4. Nombre de nœuds en fonction de N
# ============================================================

plt.figure(figsize=(8, 5))
plt.plot(ed25519["N"], ed25519["nodes"], marker="o", label="Ed25519")
plt.plot(dsa["N"], dsa["nodes"], marker="o", label="DSA")

plt.xscale("log", base=2)
plt.yscale("log")

plt.xlabel("Nombre de messages N")
plt.ylabel("Nombre de nœuds")
plt.title("Nombre de nœuds générés")
plt.grid(True, which="both")
plt.legend()

save_plot("comparaison_nombre_noeuds.png")


# ============================================================
# 5. Profondeur de l’arbre
# ============================================================

plt.figure(figsize=(8, 5))
plt.plot(ed25519["N"], ed25519["depth"], marker="o", label="Ed25519, t=4")
plt.plot(dsa["N"], dsa["depth"], marker="o", label="DSA, t=3")

plt.xscale("log", base=2)

plt.xlabel("Nombre de messages N")
plt.ylabel("Profondeur depth")
plt.title("Évolution de la profondeur de l’arbre")
plt.grid(True, which="both")
plt.legend()

save_plot("comparaison_depth.png")


# ============================================================
# 6. Comparaison à N communs : 256, 1024, 4096
# ============================================================

common_N = [256, 1024, 4096]

ed_common_build = []
ed_common_sign = []
ed_common_avg = []

dsa_common_build = []
dsa_common_sign = []
dsa_common_avg = []

for n in common_N:
    i_ed = ed25519["N"].index(n)
    i_dsa = dsa["N"].index(n)

    ed_common_build.append(ed25519["build_ms"][i_ed])
    ed_common_sign.append(ed25519["sign_ms"][i_ed])
    ed_common_avg.append(ed25519["ms_per_sign"][i_ed])

    dsa_common_build.append(dsa["build_ms"][i_dsa])
    dsa_common_sign.append(dsa["sign_ms"][i_dsa])
    dsa_common_avg.append(dsa["ms_per_sign"][i_dsa])


# Temps de construction sur N communs
x = range(len(common_N))
width = 0.35

plt.figure(figsize=(8, 5))
plt.bar([i - width / 2 for i in x], ed_common_build, width, label="Ed25519")
plt.bar([i + width / 2 for i in x], dsa_common_build, width, label="DSA")

plt.xticks(list(x), [str(n) for n in common_N])
plt.xlabel("Nombre de messages N")
plt.ylabel("Temps de construction (ms)")
plt.title("Temps de construction pour les mêmes valeurs de N")
plt.grid(True, axis="y")
plt.legend()

save_plot("comparaison_build_communs.png")


# Temps signature + vérification sur N communs
plt.figure(figsize=(8, 5))
plt.bar([i - width / 2 for i in x], ed_common_sign, width, label="Ed25519")
plt.bar([i + width / 2 for i in x], dsa_common_sign, width, label="DSA")

plt.xticks(list(x), [str(n) for n in common_N])
plt.xlabel("Nombre de messages N")
plt.ylabel("Temps signature + vérification (ms)")
plt.title("Signature + vérification pour les mêmes valeurs de N")
plt.grid(True, axis="y")
plt.legend()

save_plot("comparaison_sign_communs.png")


# Temps moyen par signature sur N communs
plt.figure(figsize=(8, 5))
plt.bar([i - width / 2 for i in x], ed_common_avg, width, label="Ed25519")
plt.bar([i + width / 2 for i in x], dsa_common_avg, width, label="DSA")

plt.xticks(list(x), [str(n) for n in common_N])
plt.xlabel("Nombre de messages N")
plt.ylabel("Temps moyen par signature (ms)")
plt.title("Temps moyen par signature pour les mêmes valeurs de N")
plt.grid(True, axis="y")
plt.legend()

save_plot("comparaison_avg_communs.png")


print("Graphiques générés avec succès.")
