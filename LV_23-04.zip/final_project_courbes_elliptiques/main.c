#include <stdio.h>
#include <time.h>
#include "signature_tree_openssl.h"

/*
 * ============================================================
 * Fichier : main.c
 * ============================================================
 *
 * Rôle :
 *   Ce fichier montre un exemple d'utilisation du module
 *   signature_tree_openssl.
 *
 * Ce que fait ce programme :
 *   1) initialise OpenSSL,
 *   2) crée la racine de l'arbre,
 *   3) construit un arbre t-aire de profondeur donnée,
 *   4) affiche l'arbre initial,
 *   5) signe plusieurs messages successivement,
 *   6) vérifie chaque signature produite,
 *   7) affiche l'état final de l'arbre,
 *   8) libère toute la mémoire.
 *
 * Mesure du temps :
 *   On utilise clock_gettime(CLOCK_MONOTONIC) pour mesurer
 *   avec précision (nanoseconde) le temps de chaque phase :
 *     - construction de l'arbre,
 *     - boucle de signatures + vérifications,
 *     - libération mémoire.
 *   Un récapitulatif est affiché en fin de programme.
 */

/*
 * ============================================================
 * Macro utilitaire : TIME_DIFF_MS
 * ============================================================
 *
 * Calcule la différence en millisecondes entre deux struct timespec.
 *
 * Paramètres :
 *   start : instant de départ  (struct timespec)
 *   end   : instant de fin     (struct timespec)
 *
 * Retour :
 *   double — durée en millisecondes
 */
#define TIME_DIFF_MS(start, end) \
    (((end).tv_sec  - (start).tv_sec)  * 1000.0 + \
     ((end).tv_nsec - (start).tv_nsec) / 1000000.0)

int main(void) {

    /* Horloges pour chaque phase */
    struct timespec t0, t1, t2, t3, t4, t5;

    /* Durées calculées (en ms) */
    double time_build   = 0.0;
    double time_sign    = 0.0;
    double time_free    = 0.0;
    double time_total   = 0.0;

    /* ── Début du chronomètre global ─────────────────────── */
    clock_gettime(CLOCK_MONOTONIC, &t0);

    /*
     * Initialisation de la bibliothèque OpenSSL.
     * Doit être faite avant les opérations cryptographiques.
     */
    st_openssl_init();

    /*
     * t :
     *   facteur de branchement de l'arbre.
     *   Chaque nœud interne aura exactement t fils.
     *
     * depth :
     *   profondeur en nombre de niveaux de nœuds.
     *
     * Exemple :
     *   depth = 3, t = 3
     *   -> niveau 0 : 1 racine
     *   -> niveau 1 : 3 fils
     *   -> niveau 2 : 9 nœuds terminaux
     *   -> chaque nœud terminal contient 3 feuilles-message
     */
    const size_t t = 3;
    const size_t depth = 3;

    /*
     * Tableau de messages utilisé dans chaque nœud terminal.
     * Comme t = 3, il faut fournir exactement 3 messages.
     */
    const char *messages[] = {
        "message_1",
        "message_2",
        "message_3"
    };

    /*
     * Création de la racine.
     * Cette fonction génère automatiquement une paire de clés Ed25519.
     */
    ST_SignatureNode *root = st_create_node();

    /* ── Phase 1 : construction de l'arbre ───────────────── */
    clock_gettime(CLOCK_MONOTONIC, &t1);

    /*
     * Construction récursive de tout l'arbre.
     */
    st_build_tree(root, depth, t, messages);

    clock_gettime(CLOCK_MONOTONIC, &t2);
    time_build = TIME_DIFF_MS(t1, t2);

    /*
     * Affichage initial de l'arbre.
     */
    printf("===== ARBRE INITIAL =====\n");
    st_print_tree(root, 0);

    /*
     * Affichage de quelques statistiques globales.
     */
    printf("\nStats initiales:\n");
    printf("- total nodes   : %zu\n", st_count_total_nodes(root));
    printf("- total leaves  : %zu\n", st_count_total_leaves(root));
    printf("- signed leaves : %zu\n", st_count_signed_leaves(root));

    /* ── Phase 2 : signatures et vérifications ───────────── */
    clock_gettime(CLOCK_MONOTONIC, &t3);

    /*
     * On tente ici de signer 5 messages successifs.
     * À chaque tour :
     *   - on récupère le prochain message libre,
     *   - on le signe,
     *   - on vérifie le chemin complet,
     *   - on libère ensuite le résultat.
     */
    printf("\n===== SIGNATURES =====\n");
    for (int i = 0; i < 5; i++) {

        /* Mesure individuelle par signature */
        struct timespec ts0, ts1;
        clock_gettime(CLOCK_MONOTONIC, &ts0);

        ST_SignResult res = st_sign_next_message(root, depth);

        clock_gettime(CLOCK_MONOTONIC, &ts1);

        /*
         * Si success == 0, cela signifie qu'il n'existe plus
         * aucun message non signé dans l'arbre.
         */
        if (!res.success) {
            printf("Plus aucun message disponible.\n");
            st_free_sign_result(&res);
            break;
        }

        printf("Signature #%d\n", i + 1);
        printf("  message      : %s\n", res.message);
        printf("  leaf_index   : %zu\n", res.leaf_index);
        printf("  path_len     : %zu\n", res.path_len);

        /*
         * Vérification cryptographique complète :
         *   - authentification des clés publiques le long du chemin
         *   - vérification de la signature finale du message
         */
        printf("  verification : %s\n",
               st_verify_sign_result(&res) ? "OK" : "ECHEC");

        /* Affichage du temps pour cette signature seule */
        printf("  time         : %.4f ms\n", TIME_DIFF_MS(ts0, ts1));

        /*
         * Important :
         * le résultat contient de la mémoire dynamique,
         * donc il faut le libérer après usage.
         */
        st_free_sign_result(&res);
    }

    clock_gettime(CLOCK_MONOTONIC, &t4);
    time_sign = TIME_DIFF_MS(t3, t4);

    /*
     * Affichage de l'arbre après plusieurs signatures.
     */
    printf("\n===== ARBRE FINAL =====\n");
    st_print_tree(root, 0);

    /* ── Phase 3 : libération mémoire ────────────────────── */
    clock_gettime(CLOCK_MONOTONIC, &t4);

    /*
     * Libération complète de l'arbre.
     */
    st_free_tree(root);

    clock_gettime(CLOCK_MONOTONIC, &t5);
    time_free = TIME_DIFF_MS(t4, t5);

    /*
     * Nettoyage final d'OpenSSL.
     */
    st_openssl_cleanup();

    /* ── Fin du chronomètre global ───────────────────────── */
    time_total = TIME_DIFF_MS(t0, t5);

    /* ── Récapitulatif des temps ─────────────────────────── */
    printf("\n===== MESURES DE TEMPS =====\n");
    printf("  Construction de l'arbre  : %8.4f ms\n", time_build);
    printf("  Signatures + vérifs      : %8.4f ms\n", time_sign);
    printf("  Libération mémoire       : %8.4f ms\n", time_free);
    printf("  ─────────────────────────────────────\n");
    printf("  Temps total (global)     : %8.4f ms\n", time_total);

    return 0;
}