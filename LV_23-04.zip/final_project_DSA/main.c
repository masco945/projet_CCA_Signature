#include <stdio.h>
#include "signature_tree_openssl.h"

/*
 * ============================================================
 * Fichier : main.c
 * ============================================================
 *
 * Rôle :
 *   Fournir un exemple d'utilisation du module
 *   signature_tree_openssl en version DSA.
 *
 * Ce programme :
 *   1) initialise OpenSSL,
 *   2) génère des paramètres DSA communs (p, q, g),
 *   3) crée la racine de l'arbre,
 *   4) construit l'arbre t-aire,
 *   5) affiche l'arbre initial,
 *   6) signe plusieurs messages successifs,
 *   7) vérifie chaque signature produite,
 *   8) affiche l'état final de l'arbre,
 *   9) libère toutes les ressources.
 */

int main(void) {
    /*
     * Initialisation globale d'OpenSSL.
     */
    st_openssl_init();

    /*
     * Paramètres DSA communs.
     *
     * p_bits :
     *   taille du premier p.
     *
     * q_bits :
     *   taille du sous-groupe q.
     *
     * Un choix classique est :
     *   p = 2048 bits
     *   q = 256 bits
     */
    const int p_bits = 2048;
    const int q_bits = 256;

    /*
     * Facteur de branchement t :
     * chaque nœud interne aura exactement t fils.
     *
     * depth :
     * nombre de niveaux de nœuds.
     *
     * Exemple avec t = 3 et depth = 3 :
     *   niveau 0 : 1 racine
     *   niveau 1 : 3 fils
     *   niveau 2 : 9 nœuds terminaux
     *   chaque terminal contient 3 feuilles-message
     */
    const size_t t = 3;
    const size_t depth = 3;

    /*
     * Messages placés dans chaque nœud terminal.
     * Il faut en fournir exactement t.
     */
    const char *messages[] = {
        "message_1",
        "message_2",
        "message_3"
    };

    /*
     * Génération des paramètres DSA communs.
     * Tous les nœuds de l'arbre utiliseront les mêmes paramètres
     * (p, q, g), mais auront chacun leur propre paire de clés.
     */
    EVP_PKEY *dsa_params = st_generate_dsa_parameters(p_bits, q_bits);

    /*
     * Création de la racine avec une paire de clés DSA.
     */
    ST_SignatureNode *root = st_create_node(dsa_params);

    /*
     * Construction complète de l'arbre de signature.
     */
    st_build_tree(root, dsa_params, depth, t, messages);

    /*
     * Les paramètres DSA ont servi à générer toutes les clés.
     * Ils ne sont plus nécessaires ensuite.
     */
    EVP_PKEY_free(dsa_params);

    printf("===== ARBRE INITIAL =====\n");
    st_print_tree(root, 0);

    printf("\nStats initiales:\n");
    printf("- total nodes   : %zu\n", st_count_total_nodes(root));
    printf("- total leaves  : %zu\n", st_count_total_leaves(root));
    printf("- signed leaves : %zu\n", st_count_signed_leaves(root));

    /*
     * On signe ici plusieurs messages successifs.
     * À chaque tour :
     *   - on récupère le prochain message libre,
     *   - on le signe,
     *   - on vérifie tout le chemin racine -> feuille.
     */
    printf("\n===== SIGNATURES =====\n");
    for (int i = 0; i < 5; i++) {
        ST_SignResult res = st_sign_next_message(root, depth);

        if (!res.success) {
            printf("Plus aucun message disponible.\n");
            st_free_sign_result(&res);
            break;
        }

        printf("Signature #%d\n", i + 1);
        printf("  message      : %s\n", res.message);
        printf("  leaf_index   : %zu\n", res.leaf_index);
        printf("  path_len     : %zu\n", res.path_len);

        /*
         * Vérification complète :
         *   - authentification des clés publiques le long du chemin,
         *   - vérification de la signature finale du message.
         */
        printf("  verification : %s\n",
               st_verify_sign_result(&res) ? "OK" : "ECHEC");

        /*
         * Le résultat contient de la mémoire dynamique,
         * donc il faut le nettoyer après usage.
         */
        st_free_sign_result(&res);
    }

    printf("\n===== ARBRE FINAL =====\n");
    st_print_tree(root, 0);

    /*
     * Libération récursive de tout l'arbre.
     */
    st_free_tree(root);

    /*
     * Nettoyage final d'OpenSSL.
     */
    st_openssl_cleanup();

    return 0;
}