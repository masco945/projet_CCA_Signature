#ifndef SIGNATURE_TREE_OPENSSL_H
#define SIGNATURE_TREE_OPENSSL_H

/*
 * ============================================================
 * Fichier : signature_tree_openssl.h
 * ============================================================
 *
 * Rôle :
 *   Déclarer l'API publique du module d'arbre de signature
 *   basé sur OpenSSL + DSA.
 *
 * Idée générale :
 *   - chaque nœud de l'arbre possède une paire de clés DSA,
 *   - toutes les paires de clés sont générées à partir des
 *     mêmes paramètres DSA (p, q, g),
 *   - chaque nœud interne possède t fils,
 *   - la clé publique du fils est signée par le parent,
 *   - chaque nœud terminal contient t messages signables.
 *
 * Remarque importante :
 *   Contrairement à Ed25519, DSA n'est pas basé sur les courbes
 *   elliptiques ici. Il repose sur un sous-groupe du groupe
 *   multiplicatif d'un corps fini.
 */

#include <stddef.h>
#include <openssl/evp.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Taille maximale d'un message stocké dans une feuille terminale.
 */
#define ST_MAX_MSG_LEN 256

/*
 * ============================================================
 * Structure : ST_Buffer
 * ============================================================
 *
 * Rôle :
 *   Représenter un buffer dynamique d'octets.
 *
 * Utilisation :
 *   Sert à stocker :
 *   - une signature,
 *   - une clé publique DER,
 *   - ou tout autre bloc d'octets.
 */
typedef struct {
    unsigned char *data;
    size_t len;
} ST_Buffer;

/*
 * ============================================================
 * Structure : ST_MessageLeaf
 * ============================================================
 *
 * Rôle :
 *   Représenter une feuille terminale contenant :
 *   - un message,
 *   - sa signature éventuelle,
 *   - un indicateur d'usage.
 *
 * Champs :
 *   message : chaîne du message à signer
 *   sig     : signature DSA du message
 *   used    : 0 si le message n'a pas encore été signé,
 *             1 sinon
 */
typedef struct {
    char message[ST_MAX_MSG_LEN];
    ST_Buffer sig;
    int used;
} ST_MessageLeaf;

/*
 * ============================================================
 * Structure : ST_SignatureNode
 * ============================================================
 *
 * Rôle :
 *   Représenter un nœud de l'arbre de signature.
 *
 * Chaque nœud contient :
 *   - une paire de clés DSA (dans pkey),
 *   - sa clé publique encodée en DER,
 *   - la signature de cette clé publique par le parent,
 *   - ses fils éventuels,
 *   - ses feuilles terminales éventuelles.
 *
 * Champs :
 *   pkey :
 *       clé OpenSSL contenant la paire de clés DSA du nœud.
 *
 *   pubkey_der :
 *       clé publique du nœud, encodée en DER (SubjectPublicKeyInfo).
 *       Ce format est pratique pour :
 *       - stocker la clé publique,
 *       - la signer,
 *       - la reconstruire plus tard pour vérifier une signature.
 *
 *   auth_from_parent :
 *       signature de pubkey_der par la clé privée du parent.
 *
 *   has_parent_auth :
 *       vaut 0 pour la racine,
 *       vaut 1 pour les autres nœuds.
 *
 *   children / nb_children :
 *       tableau dynamique des fils du nœud.
 *
 *   leaves / nb_leaves :
 *       tableau des feuilles terminales si le nœud est terminal.
 */
typedef struct ST_SignatureNode {
    EVP_PKEY *pkey;

    ST_Buffer pubkey_der;

    ST_Buffer auth_from_parent;
    int has_parent_auth;

    struct ST_SignatureNode **children;
    size_t nb_children;

    ST_MessageLeaf *leaves;
    size_t nb_leaves;
} ST_SignatureNode;

/*
 * ============================================================
 * Structure : ST_SignResult
 * ============================================================
 *
 * Rôle :
 *   Représenter le résultat complet d'une opération de signature.
 *
 * Contient :
 *   - le message signé,
 *   - sa signature,
 *   - le chemin de nœuds racine -> nœud terminal,
 *   - les indices des fils suivis,
 *   - l'indice de la feuille utilisée.
 */
typedef struct {
    int success;

    char message[ST_MAX_MSG_LEN];
    ST_Buffer message_signature;

    ST_SignatureNode **path_nodes;
    size_t *path_child_indexes;
    size_t path_len;

    size_t leaf_index;
} ST_SignResult;

/*
 * ============================================================
 * INITIALISATION OPENSSL
 * ============================================================
 */

/*
 * Initialise OpenSSL pour le module.
 * À appeler une fois au début du programme.
 */
void st_openssl_init(void);

/*
 * Nettoie les ressources globales OpenSSL.
 * À appeler en fin de programme.
 */
void st_openssl_cleanup(void);

/*
 * ============================================================
 * GESTION DES BUFFERS
 * ============================================================
 */

/*
 * Initialise un buffer vide.
 */
void st_buffer_init(ST_Buffer *b);

/*
 * Libère le contenu d'un buffer et le remet à l'état vide.
 */
void st_buffer_free(ST_Buffer *b);

/*
 * ============================================================
 * PARAMETRES DSA
 * ============================================================
 */

/*
 * Génère des paramètres DSA communs (p, q, g).
 *
 * Paramètres :
 *   p_bits : taille du premier p en bits (ex: 2048)
 *   q_bits : taille du sous-groupe q en bits (ex: 256)
 *
 * Retour :
 *   Un EVP_PKEY* contenant uniquement les paramètres DSA.
 *
 * Remarque :
 *   Ce résultat n'est pas une paire de clés, seulement les paramètres.
 */
EVP_PKEY *st_generate_dsa_parameters(int p_bits, int q_bits);

/*
 * ============================================================
 * CONSTRUCTION DE L'ARBRE
 * ============================================================
 */

/*
 * Crée un nouveau nœud avec une nouvelle paire de clés DSA
 * dérivée des paramètres DSA communs.
 *
 * Paramètre :
 *   dsa_params : paramètres DSA communs (p, q, g)
 *
 * Retour :
 *   Pointeur vers le nœud créé.
 */
ST_SignatureNode *st_create_node(EVP_PKEY *dsa_params);

/*
 * Ajoute un fils à un parent.
 *
 * Effet :
 *   - crée une nouvelle paire de clés DSA pour le fils,
 *   - signe sa clé publique DER avec la clé privée du parent,
 *   - ajoute le fils au tableau children du parent.
 *
 * Paramètres :
 *   parent     : parent recevant le fils
 *   dsa_params : paramètres DSA communs
 *
 * Retour :
 *   Pointeur vers le fils créé.
 */
ST_SignatureNode *st_add_child(ST_SignatureNode *parent, EVP_PKEY *dsa_params);

/*
 * Ajoute t feuilles terminales à un nœud.
 *
 * Paramètres :
 *   node     : nœud terminal
 *   t        : nombre de feuilles à ajouter
 *   messages : tableau de t messages
 */
void st_add_message_leaves(ST_SignatureNode *node, size_t t, const char *messages[]);

/*
 * Construit récursivement un arbre t-aire de profondeur depth.
 *
 * Paramètres :
 *   node       : nœud racine du sous-arbre courant
 *   dsa_params : paramètres DSA communs
 *   depth      : profondeur restante
 *   t          : facteur de branchement
 *   messages   : messages des nœuds terminaux
 *
 * Convention :
 *   - si depth == 1 : node devient terminal et reçoit t feuilles
 *   - sinon : node reçoit t fils, puis on construit récursivement
 *             les sous-arbres de ses fils
 */
void st_build_tree(ST_SignatureNode *node,
                   EVP_PKEY *dsa_params,
                   size_t depth,
                   size_t t,
                   const char *messages[]);

/*
 * ============================================================
 * AFFICHAGE / STATISTIQUES
 * ============================================================
 */

/*
 * Affiche récursivement l'arbre à partir d'un nœud.
 *
 * Paramètres :
 *   node  : nœud à afficher
 *   level : niveau courant pour l'indentation
 */
void st_print_tree(const ST_SignatureNode *node, size_t level);

/*
 * Compte le nombre total de nœuds du sous-arbre.
 */
size_t st_count_total_nodes(const ST_SignatureNode *node);

/*
 * Compte le nombre total de feuilles terminales du sous-arbre.
 */
size_t st_count_total_leaves(const ST_SignatureNode *node);

/*
 * Compte le nombre total de feuilles déjà signées.
 */
size_t st_count_signed_leaves(const ST_SignatureNode *node);

/*
 * ============================================================
 * SIGNATURE / VERIFICATION
 * ============================================================
 */

/*
 * Signe le prochain message disponible dans l'arbre.
 *
 * Paramètres :
 *   root      : racine de l'arbre
 *   max_depth : profondeur maximale d'un chemin racine -> terminal
 *
 * Retour :
 *   Une structure ST_SignResult.
 *   Si success == 0, cela signifie qu'il n'y a plus de message libre.
 */
ST_SignResult st_sign_next_message(ST_SignatureNode *root, size_t max_depth);

/*
 * Libère la mémoire dynamique contenue dans un ST_SignResult.
 */
void st_free_sign_result(ST_SignResult *res);

/*
 * Vérifie complètement un résultat de signature.
 *
 * Vérifications :
 *   1) chaque clé publique enfant signée par son parent,
 *   2) la signature finale du message.
 *
 * Retour :
 *   1 si tout est valide, 0 sinon.
 */
int st_verify_sign_result(const ST_SignResult *res);

/*
 * ============================================================
 * LIBERATION MEMOIRE
 * ============================================================
 */

/*
 * Libère récursivement tout l'arbre.
 */
void st_free_tree(ST_SignatureNode *node);

#ifdef __cplusplus
}
#endif

#endif